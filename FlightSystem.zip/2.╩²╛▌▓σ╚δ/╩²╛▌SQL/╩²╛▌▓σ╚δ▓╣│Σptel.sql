use flightsystem
go
update passenger
set ptel='13694493359' 
where pno='210881198008182599'
go
update passenger 
set ptel='13482942593' 
where pno='330182197505166697'
go
update passenger 
set ptel='14014903241' 
where pno='53032119800803815X'
go
update passenger 
set ptel='13670846247' 
where pno='232723198609151612'
go
update passenger 
set ptel='15116292375' 
where pno='141128199602172833'
go
update passenger 
set ptel='15733878552' 
where pno='152922199901035431'
go
update passenger 
set ptel='14138096338' 
where pno='445224197104083577'
go
update passenger 
set ptel='13698264026' 
where pno='522723196903134119'
go
update passenger 
set ptel='15868047827' 
where pno='370702199003139135'
go
update passenger 
set ptel='15915858298' 
where pno='220105197002118396'
go
update passenger 
set ptel='13991053611' 
where pno='431223198610209411'
go
update passenger 
set ptel='13996154904' 
where pno='630123196907212533'
go
update passenger 
set ptel='15429087108' 
where pno='420281199109123599'
go
update passenger 
set ptel='15379332244' 
where pno='150929197805269653'
go
update passenger 
set ptel='15222159277' 
where pno='140181198102135717'
go
update passenger 
set ptel='15566429281' 
where pno='441226199805249814'
go
update passenger 
set ptel='13349929016' 
where pno='445322197208214554'
go
update passenger 
set ptel='14346811401' 
where pno='140882199703094235'
go
update passenger 
set ptel='14132769471' 
where pno='130684197606012251'
go
update passenger 
set ptel='14088829588' 
where pno='370321198310076616'
go
update passenger 
set ptel='15447596257' 
where pno='331081200003045813'
go
update passenger 
set ptel='13884205186' 
where pno='513233197101237959'
go
update passenger 
set ptel='13954401594' 
where pno='420606197911093430'
go
update passenger 
set ptel='13847492790' 
where pno='511101198110255311'
go
update passenger 
set ptel='15525927942' 
where pno='654022199308051650'
go
update passenger 
set ptel='15211246263' 
where pno='451321197610073755'
go
update passenger 
set ptel='14012169963' 
where pno='511826197701191293'
go
update passenger 
set ptel='13782512879' 
where pno='650109199205163597'
go
update passenger 
set ptel='13420892089' 
where pno='130921197108111274'
go
update passenger 
set ptel='14551280581' 
where pno='350901199203228010'
go
update passenger 
set ptel='14242286735' 
where pno='371302199005058952'
go
update passenger 
set ptel='13366503381' 
where pno='411681198005052278'
go
update passenger 
set ptel='14970898121' 
where pno='41172619970817113X'
go
update passenger 
set ptel='15820329868' 
where pno='510401198807138233'
go
update passenger 
set ptel='14629367266' 
where pno='210903199509111159'
go
update passenger 
set ptel='14661598538' 
where pno='530923198505078799'
go
update passenger 
set ptel='15712109369' 
where pno='150423197206119172'
go
update passenger 
set ptel='15041154134' 
where pno='13042419720619479X'
go
update passenger 
set ptel='13032089906' 
where pno='150823197207275750'
go
update passenger 
set ptel='15368822383' 
where pno='330424199608036299'
go
update passenger 
set ptel='15598755568' 
where pno='520624199403176438'
go
update passenger 
set ptel='14382314169' 
where pno='130129198207250298'
go
update passenger 
set ptel='14130313903' 
where pno='652929199505189095'
go
update passenger 
set ptel='14834038090' 
where pno='542521198311049673'
go
update passenger 
set ptel='14248445361' 
where pno='451121197610058474'
go
update passenger 
set ptel='14222234046' 
where pno='450330198211147876'
go
update passenger 
set ptel='14368586498' 
where pno='469028197808183017'
go
update passenger 
set ptel='15470123624' 
where pno='220301198807075290'
go
update passenger 
set ptel='13612478798' 
where pno='431028199107252557'
go
update passenger 
set ptel='14238263618' 
where pno='220284198803018040'
go
update passenger 
set ptel='15121108132' 
where pno='22018319970512554X'
go
update passenger 
set ptel='14135727667' 
where pno='420104196901108163'
go
update passenger 
set ptel='14671159833' 
where pno='150721198303195765'
go
update passenger 
set ptel='14820741021' 
where pno='450224199510221820'
go
update passenger 
set ptel='15323114401' 
where pno='330326197101163529'
go
update passenger 
set ptel='14563934327' 
where pno='350581198101054246'
go
update passenger 
set ptel='14254108828' 
where pno='350504199004178409'
go
update passenger 
set ptel='14212055170' 
where pno='210811199108103005'
go
update passenger 
set ptel='14353688555' 
where pno='431023198805197106'
go
update passenger 
set ptel='14726121163' 
where pno='320703198409130942'
go
update passenger 
set ptel='13885575050' 
where pno='231086197603186904'
go
update passenger 
set ptel='14970708262' 
where pno='510726198302230804'
go
update passenger 
set ptel='14143574005' 
where pno='640381199804201647'
go
update passenger 
set ptel='14083930635' 
where pno='36073219800607894X'
go
update passenger 
set ptel='14454749172' 
where pno='42070319970927572X'
go
update passenger 
set ptel='15460378277' 
where pno='610202198803034989'
go
update passenger 
set ptel='15879868137' 
where pno='340828198908112841'
go
update passenger 
set ptel='14615423655' 
where pno='130433200008177324'
go
update passenger 
set ptel='14111075776' 
where pno='62052119771007620X'
go
update passenger 
set ptel='15763981473' 
where pno='520113198506134168'
go
update passenger 
set ptel='13944282012' 
where pno='220501198209236147'
go
update passenger 
set ptel='14629346561' 
where pno='610729198103078785'
go
update passenger 
set ptel='14184565848' 
where pno='320481199701175520'
go
update passenger 
set ptel='13822734892' 
where pno='340103198707233326'
go
update passenger 
set ptel='15015497046' 
where pno='659001199803171222'
go
update passenger 
set ptel='14459152722' 
where pno='522730198308107362'
go
update passenger 
set ptel='14831109279' 
where pno='360924200007172285'
go
update passenger 
set ptel='14621885663' 
where pno='341004197504040281'
go
update passenger 
set ptel='15956702381' 
where pno='130827197307138843'
go
update passenger 
set ptel='14439565038' 
where pno='230184197906096908'
go
update passenger 
set ptel='14127873695' 
where pno='540531198810258243'
go
update passenger 
set ptel='13971439468' 
where pno='341201197202154904'
go
update passenger 
set ptel='14792758955' 
where pno='36102219991024818X'
go
update passenger 
set ptel='13281384425' 
where pno='13068119890522492X'
go
update passenger 
set ptel='14343185323' 
where pno='63280219691016290X'
go
update passenger 
set ptel='14836891114' 
where pno='530624199802082385'
go
update passenger 
set ptel='14477984434' 
where pno='431201197602033484'
go
update passenger 
set ptel='13631822395' 
where pno='53072119730907184X'
go
update passenger 
set ptel='15377047524' 
where pno='530624199908047027'
go
update passenger 
set ptel='15561618959' 
where pno='13022419700823530X'
go
update passenger 
set ptel='14773942500' 
where pno='150981198202245441'
go
update passenger 
set ptel='15958523392' 
where pno='370181198909012227'
go
update passenger 
set ptel='14588761746' 
where pno='330324198307258680'
go
update passenger 
set ptel='15539281451' 
where pno='530822197207095789'
go
update passenger 
set ptel='13822424751' 
where pno='211301199906225622'
go
update passenger 
set ptel='13293667459' 
where pno='510521198307229922'
go
update passenger 
set ptel='13386671513' 
where pno='220303196909164167'
go
update passenger 
set ptel='14381212818' 
where pno='420113199209060845'
go
update passenger 
set ptel='13595678502' 
where pno='210602198809086867'
go
update passenger 
set ptel='13717626524' 
where pno='210321197311078884'
go
