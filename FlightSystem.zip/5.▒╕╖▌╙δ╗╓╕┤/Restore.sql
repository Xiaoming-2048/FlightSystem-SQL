restore database FlightSystem from FSBACKUP
go